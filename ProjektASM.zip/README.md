# Bitmap-color-balance
I made GUI using WPF, algorithm will be written in C# and ASM
I try to do multithreading using parallel.for
